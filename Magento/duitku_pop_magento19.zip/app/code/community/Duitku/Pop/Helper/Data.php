<?php

class Duitku_Pop_Helper_Data extends Mage_Core_Helper_Abstract
{

  function _getTitle(){
    return Mage::getStoreConfig('payment/pop/title');
  }

  function _getDescription(){
    return Mage::getStoreConfig('payment/pop/payment_description');
  }

}
