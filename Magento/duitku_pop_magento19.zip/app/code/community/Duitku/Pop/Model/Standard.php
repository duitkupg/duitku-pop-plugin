<?php

class Duitku_Pop_Model_Standard extends Mage_Payment_Model_Method_Abstract
{

  protected $_code = 'pop';

  protected $_isInitializeNeeded      = true;
  protected $_canUseInternal          = true;
  protected $_canUseForMultishipping  = false;

  protected $_formBlockType = 'pop/form';
  protected $_infoBlockType = 'pop/info';

  public function getOrderPlaceRedirectUrl()
  {
    return Mage::getUrl('pop/payment/invoice', array('_secure' => true));
  }

  public function getCheckout()
  {
    return Mage::getSingleton('checkout/session');
  }

}
