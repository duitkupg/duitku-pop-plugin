<?php

/**
*
*/
class Duitku_Pop_Model_System_Config_Uimode
{

  public function toOptionArray()
  {
    return array(
      array('value' => 'popup', 'label' => Mage::helper('pop')->__('Popup')),
      array('value' => 'redirect', 'label' => Mage::helper('pop')->__('Redirect'))
    );
  }
}


?>
