<?php

/**
*
*/
class Duitku_Pop_Model_System_Config_Environment
{

  public function toOptionArray()
  {
    return array(
      array('value' => 'sandbox', 'label' => Mage::helper('pop')->__('Sandbox')),
      array('value' => 'production', 'label' => Mage::helper('pop')->__('Production'))
    );
  }
}


?>
