<?php

/**
*
*/
class Duitku_Pop_Block_Info extends Mage_Payment_Block_Info
{

  protected function _construct()
  {
    parent::_construct();
    $this->setInfoMessage('<img src="'. $this->getSkinUrl('images/Duitku.png'). '"/>');
    $this->setPaymentMethodTitle( Mage::helper('pop/data')->_getTitle() );
    $this->setTemplate('pop/info.phtml');
  }
}
