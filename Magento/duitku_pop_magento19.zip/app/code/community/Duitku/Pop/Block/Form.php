<?php

class Duitku_Pop_Block_Form extends Mage_Payment_Block_Form
{
  protected function _construct()
  {
    parent::_construct();
    $this->setFormMessage(Mage::helper('pop/data')->_getDescription());
    $this->setTemplate('pop/form.phtml');
  }
}
