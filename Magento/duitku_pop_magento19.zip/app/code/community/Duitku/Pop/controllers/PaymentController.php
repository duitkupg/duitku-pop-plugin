<?php

class Duitku_Pop_PaymentController extends Mage_Core_Controller_Front_Action
{
  protected function _getCheckout()
  {
    return Mage::getSingleton('checkout/session');
  }

  public function invoiceAction()
  {
    $orderId = $this->_getCheckout()->getLastRealOrderId();
    $orderData = Mage::getModel('sales/order')->loadByIncrementId($orderId);
    $sessionId = Mage::getSingleton('core/session');
    $merchantCode = Mage::getStoreConfig('payment/pop/merchant_code');
    $apiKey = Mage::getStoreConfig('payment/pop/api_key');
    $expiry = Mage::getStoreConfig('payment/pop/expiry_period');
    $environment = Mage::getStoreConfig('payment/pop/environment');
    $urlEndpoint = Mage::getStoreConfig('payment/pop/url_endpoint');
    $uiMode = Mage::getStoreConfig('payment/pop/ui_mode');

    $params = array();

    $billingAddressData = $orderData->getBillingAddress();
    $billingAddress = array();
    $billingAddress['address'] = $billingAddressData->getStreet(1);
    $billingAddress['city'] = $billingAddressData->getCity();
    $billingAddress['countryCode'] = "ID";
    $billingAddress['firstName'] = $billingAddressData->getFirstname();
    $billingAddress['lastName'] = $billingAddressData->getLastname();
    $billingAddress['phone'] = $billingAddressData->getTelephone();
    $billingAddress['postalCode'] = $billingAddressData->getPostcode();

    $shippingAddressData = $orderData->getShippingAddress();
    $shippingAddress = array();
    $shippingAddress['address'] = $shippingAddressData->getStreet(1);
    $shippingAddress['city'] = $shippingAddressData->getCity();
    $shippingAddress['countryCode'] = "ID";
    $shippingAddress['firstName'] = $shippingAddressData->getFirstname();
    $shippingAddress['lastName'] = $shippingAddressData->getLastname();
    $shippingAddress['phone'] = $shippingAddressData->getTelephone();
    $shippingAddress['postalCode'] = $shippingAddressData->getPostcode();

    $customerDetailParams = array();
    $customerDetailParams['email'] = $billingAddressData->getEmail();
    $customerDetailParams['firstName'] = $billingAddressData->getFirstname();
    $customerDetailParams['lastName'] = $billingAddressData->getLastname();
    $customerDetailParams['phoneNumber'] = $billingAddressData->getTelephone();
    $customerDetailParams["shippingAddress"] = $shippingAddress;
    $customerDetailParams["billingAddress"] = $billingAddress;

    $itemsData = $orderData->getAllItems();
    $shippingAmountData = $orderData->getShippingAmount();
    $shippingTaxAmountData = $orderData->getShippingTaxAmount();
    $taxAmountData = $orderData->getTaxAmount();

    $itemDetailParams = array();
    foreach ($itemsData as $value) {
      $item = array(
        'name' => $value->getName(),
        'price' => (int)$value->getPrice() * (int)($value->getQtyToInvoice()),
        'quantity' => (int)($value->getQtyToInvoice())
      );
      $itemDetailParams[] = $item;
    }

    if ($orderData->getDiscountAmount() != 0) {
      $couponItem = array(
        'name' => "Discount",
        'price' => (int)$orderData->getDiscountAmount(),
        'quantity' => 1
      );
      $itemDetailParams[] = $couponItem;
    }

    if ($shippingAmountData > 0) {
      $shippingItem = array(
        'name' => 'Shipping Amount',
        'price' => (int)$shippingAmountData,
        'quantity' => 1
      );
      $itemDetailParams[] = $shippingItem;
    }

    if ($shippingTaxAmountData > 0) {
      $shippingTaxItem = array(
        'name' => 'Shipping Tax Amount',
        'price' => (int)$shippingTaxAmountData,
        'quantity' => 1
      );
      $itemDetailParams[] = $shippingTaxItem;
    }

    if ($taxAmountData > 0) {
      $taxItem = array(
        'name' => 'Tax Amount',
        'price' => (int)$taxAmountData,
        'quantity' => 1
      );
      $itemDetailParams[] = $taxItem;
    }

    $currency = Mage::app()->getStore()->getCurrentCurencyCode();
    if ($currency != 'IDR') {
      $convert = function ($notIdr) {
        return $notIdr * Mage::getStoreConfig('payment/pop/convert_rate');
      };

      foreach ($itemDetailParams as $value) {
        $value['price'] = intval(round(call_user_func($convert, $value['price'])));
      }
    } else {
      foreach ($itemDetailParams as $value) {
        $value['price'] = (int)$value['price'];
      }
    }

    $paymentAmount = 0;
    foreach ($itemDetailParams as $item) {
      $paymentAmount += $item['price'];
    }

    //$signature = md5($merchantCode.$orderId.$paymentAmount.$apiKey);
    $baseUrl = Mage::getBaseUrl();
    $tstamp = round(microtime(true) * 1000);
    $mcode = $merchantCode;
    $header_signature = hash('sha256', $mcode . $tstamp . $apiKey);

    $params['merchantOrderId'] = $orderId;
    $params['paymentAmount'] = $paymentAmount;
    $params['phoneNumber'] = $billingAddressData->getTelephone();
    $params['productDetails'] = "Order => #" . $orderId;
    $params['email'] = $billingAddressData->getEmail();
    $params['expiryPeriod'] = (int)$expiry;
    $params['customerDetail'] = $customerDetailParams;
    $params['itemDetails'] = $itemDetailParams;
    $params['returnUrl'] = $baseUrl . 'pop/payment/return';
    $params['callbackUrl'] = $baseUrl . 'pop/payment/notify';
    $url = $urlEndpoint . "/api/merchant/createInvoice";

    Mage::log(json_encode($params), null, 'duitkupop.log', true);

    if (extension_loaded('curl')) {
      try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'Content-Type: application/json',
          'x-duitku-signature: ' . $header_signature,
          'x-duitku-timestamp: ' . $tstamp,
          'x-duitku-merchantCode: ' . $mcode
        ));
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));

        // Receive server response ...
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $server_output = curl_exec($ch);
        $hdr = array();
        $hdr['signature'] = $header_signature;
        $hdr['timestamp'] = $tstamp;
        $hdr['mcode'] = $mcode;
        $hdr['error'] = curl_error($ch);
        Mage::log(json_encode($hdr), null, 'duitkupop.log', true);
        curl_close($ch);

        $respond = json_decode($server_output);
        Mage::log(json_encode($server_output), null, 'duitkupop.log', true);

        if ($respond->statusCode == '00') {
          foreach (Mage::getSingleton('checkout/session')->getQuote()->getItemsCollection() as $value) {
            Mage::getSingleton('checkout/cart')->removeItem($value->getId())->save();
          }
          if ($uiMode == 'popup') {
            Mage::log('Reference number createInvoice = ' . $respond->reference, null, 'duitkupop.log', true);
            $this->_getCheckout()->setReference($respond->reference);
            Mage::app()->getFrontController()->getResponse()->setRedirect(Mage::getBaseUrl() . 'pop/payment/popup');
          } else {
            Mage::log('Url payment createInvoice = ' . $respond->paymentUrl, null, 'duitkupop.log', true);
            Mage::app()->getFrontController()->getResponse()->setRedirect($respond->paymentUrl);
          }
        } else {
          $this->_getCheckout()->setDuitkumessage($server_output);
          Mage::app()->getFrontController()->getResponse()->setRedirect(Mage::getBaseUrl() . 'pop/payment/warning');
          error_log("Messages " . $server_output);
          Mage::log('error:' . print_r("Messages " . $server_output, true), null, 'duitkupop.log', true);
        }
      } catch (Exception $e) {
        error_log($e->getMessage());
        Mage::log('error:' . print_r($e->getMessage(), true), null, 'duitkupop.log', true);
      }
    } else {
      error_log("Duitku payment need curl extension, please enable curl extension in your web server");
      Mage::log('error:' . print_r("Duitku payment need curl extension, please enable curl extension in your web server", true), null, 'duitkupop.log', true);
    }
  }

  public function popupAction()
  {
    $template = 'pop/popup.phtml';
    $this->loadLayout();
    $block = $this->getLayout()->createBlock(
      'Mage_Core_Block_Template',
      'pop',
      array('template' => $template)
    );

    $this->getLayout()->getBlock('root')->setTemplate('page/1column.phtml');
    $this->getLayout()->getBlock('content')->append($block);
    $this->_initLayoutMessages('core/session');
    $this->renderLayout();
  }

  public function warningAction()
  {
    $template = 'pop/warning.phtml';
    $this->loadLayout();
    $block = $this->getLayout()->createBlock(
      'Mage_Core_Block_Template',
      'pop',
      array('template' => $template)
    );
    $this->getLayout()->getBlock('root')->setTemplate('page/1column.phtml');
    $this->getLayout()->getBlock('content')->append($block);
    $this->_initLayoutMessages('core/session');
    $this->renderLayout();
  }

  public function pendingAction()
  {
    $template = 'pop/pending.phtml';
    $this->loadLayout();
    $block = $this->getLayout()->createBlock(
      'Mage_Core_Block_Template',
      'pop',
      array('template' => $template)
    );
    $this->getLayout()->getBlock('root')->setTemplate('page/1column.phtml');
    $this->getLayout()->getBlock('content')->append($block);
    $this->_initLayoutMessages('core/session');
    $this->renderLayout();
  }

  private function refillCart()
  {
    if (Mage::getSingleton('checkout/session')->getLastRealOrderId()) {
      if ($lastQuoteId = Mage::getSingleton('checkout/session')->getLastQuoteId()) {
        $quote = Mage::getModel('sales/quote')->load($lastQuoteId);
        $quote->setIsActive(true)->save();
      }
    }
  }

  public function returnAction()
  {
    $order_id = Mage::getModel('pop/standard')->getCheckout()->getLastRealOrderId();
    $view_id = Mage::getModel('pop/standard')->getCheckout()->getLastOrderId();
    $order = Mage::getModel('sales/order')->loadByIncrementId($order_id);
    if (isset($_GET['resultCode']) && isset($_GET['merchantOrderId']) && isset($_GET['reference']) && $_GET['resultCode'] == '00') {
      //if capture or pending or challenge or settlement, redirect to order received page
      $merchantcode = Mage::getStoreConfig('payment/pop/merchant_code');
      $apikey = Mage::getStoreConfig('payment/pop/api_key');
      $endpoint = Mage::getStoreConfig('payment/pop/url_endpoint');
      $url = $endpoint . '/api/merchant/transactionStatus';
      $signature = md5($merchantcode . $order_id . $apikey);
      $params = array(
        'merchantCode' => $merchantcode,
        'merchantOrderId' => $order_id,
        'signature' => $signature
      );
      if (extension_loaded('curl')) {
        try {
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
          ));
          curl_setopt($ch, CURLOPT_URL, $url);
          curl_setopt($ch, CURLOPT_POST, 1);
          curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));

          // Receive server response ...
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

          $server_output = curl_exec($ch);

          curl_close($ch);

          $respond = json_decode($server_output);
          Mage::log(json_encode($server_output), null, 'duitkupop.log', true);

          if ($respond->statusCode == '00') {
            $this->_redirect('checkout/onepage/success');
            $order->setState(Mage_Sales_Model_Order::STATE_PROCESSING, true);
            $order->save();
          } else {
            $this->_redirect('checkout/onepage/failure');
            Mage::getSingleton('core/session')->addError(__('Transaction is rejected please try again or contact administrator.'));
            $order->cancel();
            $order->save();
            $this->refillCart();
          }
        } catch (Exception $e) {
          error_log($e->getMessage());
          Mage::log('error:' . print_r($e->getMessage(), true), null, 'duitkupop.log', true);
        }
      } else {
        error_log("Duitku payment need curl extension, please enable curl extension in your web server");
        Mage::log('error:' . print_r("Duitku payment need curl extension, please enable curl extension in your web server", true), null, 'duitkupop.log', true);
      }
    } else if (isset($_GET['resultCode']) && isset($_GET['merchantOrderId']) && isset($_GET['reference']) && $_GET['resultCode'] == '01') {
      $this->_getCheckout()->setDuitkumessage($_GET['merchantOrderId'] . "-" . $view_id);
      Mage::app()->getFrontController()->getResponse()->setRedirect(Mage::getBaseUrl() . 'pop/payment/pending');
      $order->save();
    } else if (isset($_GET['resultCode']) && isset($_GET['merchantOrderId']) && isset($_GET['reference']) && $_GET['resultCode'] == '02') {
      //if deny, redirect to order checkout page again            
      $this->_redirect('checkout/onepage/failure');
      //$order->setState(Mage_Sales_Model_Order::STATE_CANCELED, true);            
      Mage::getSingleton('core/session')->addError(__('Transaction is rejected please try again or contact administrator.'));
      $order->cancel();
      $order->save();
      $this->refillCart();
    } else {
      $this->refillCart();
      Mage_Core_Controller_Varien_Action::_redirect('');
    }
  }

  public function notifyAction()
  {
    if (empty($_REQUEST['resultCode']) || empty($_REQUEST['merchantOrderId']) || empty($_REQUEST['reference'])) {
      throw new Exception(__('wrong query string please contact admin.', 'duitku'));
    }

    $order_id = stripslashes($_REQUEST['merchantOrderId']);
    $order = Mage::getModel('sales/order')->loadByIncrementId($order_id);

    $status = stripslashes($_REQUEST['resultCode']);
    $reference = stripslashes($_REQUEST['reference']);

    $merchantcode = Mage::getStoreConfig('payment/pop/merchant_code');
    $apikey = Mage::getStoreConfig('payment/pop/api_key');
    $endpoint = Mage::getStoreConfig('payment/pop/url_endpoint');
    $url = $endpoint . '/api/merchant/transactionStatus';
    $signature = md5($merchantcode . $order_id . $apikey);
    $params = array(
      'merchantCode' => $merchantcode,
      'merchantOrderId' => $order_id,
      'signature' => $signature
    );
    if (extension_loaded('curl')) {
      try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'Content-Type: application/json',
        ));
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));

        // Receive server response ...
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $server_output = curl_exec($ch);

        curl_close($ch);

        $respond = json_decode($server_output);
        Mage::log(json_encode($server_output), null, 'duitkupop.log', true);

        //check if order id is in the database
        if ($order) {
          if ($status == '00' && $respond->statusCode == '00') {
            $invoice = $order->prepareInvoice();
            $invoice->register();
            $order->addRelatedObject($invoice);
            $order->setState(Mage_Sales_Model_Order::STATE_PROCESSING, true);
            $order->sendNewOrderEmail();
            $order->save();
          } else {
            throw new Exception(__('the order number ' .  $order_id . ' cannot be validated.', 'duitku'));
          }
        } else {
          throw new Exception(__('the order number ' .  $order_id . ' cannot be   validated.', 'duitku'));
        }
      } catch (Exception $e) {
        error_log($e->getMessage());
        Mage::log('error:' . print_r($e->getMessage(), true), null, 'duitkupop.log', true);
      }
    } else {
      error_log("Duitku payment need curl extension, please enable curl extension in your web server");
      Mage::log('error:' . print_r("Duitku payment need curl extension, please enable curl extension in your web server", true), null, 'duitkupop.log', true);
    }
  }
}
