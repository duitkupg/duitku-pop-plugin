<?php

namespace Duitku\Pop\Plugin;

class CsrfValidatorSkip
{
  public function aroundValidate($subject, \Closure $proceed, $request, $action)
  {
    if ($request->getModuleName() == 'duitkupop') {
      return;
    }
    $proceed($request, $action);
  }
}
