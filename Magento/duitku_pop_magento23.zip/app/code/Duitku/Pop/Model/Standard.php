<?php
namespace Duitku\Pop\Model;
class Standard extends \Magento\Payment\Model\Method\AbstractMethod {
  const TRX_STATUS_SETTLEMENT = 'settlement';
  const ORDER_STATUS_EXPIRE = 'expire';
  protected $_code = 'duitkupop';

  protected $_isInitializeNeeded = true;
  protected $_canUseInternal = true;
  protected $_canUseForMultishipping = false;

  protected $_formBlockType = 'duitkupop/form';
  protected $_infoBlockType = 'duitkupop/info';

  public function getOrderPlaceRedirectUrl() {
    return 'http://www.google.com/';
  }
}
