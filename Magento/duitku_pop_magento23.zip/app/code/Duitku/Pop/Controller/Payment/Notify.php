<?php

namespace Duitku\Pop\Controller\Payment;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\View\Element\Messages;

class Notify extends \Magento\Framework\App\Action\Action
{
  protected $_checkoutSession;
  protected $_logger;
  protected $_coreSession;

  public function __construct(\Magento\Framework\App\Action\Context $context, \Magento\Framework\Session\SessionManagerInterface $coreSession, \Magento\Framework\Message\ManagerInterface $messageManager)
  {
    parent::__construct($context);
    $this->_coreSession = $coreSession;
    $this->_messageManager = $messageManager;
  }

  public function execute()
  {
    try {
      $message = '';
      $posted = $this->getRequest()->getParams();
      $om = $this->_objectManager;

      if (empty($posted['merchantOrderId']) || empty($posted['resultCode']) || empty($posted['reference'])) {
        $message = "Parameteres are missing. Request: " . json_encode($posted);
        echo $message;
        exit();
      }

      $order = $om->get('Magento\Sales\Model\Order')->load($posted['merchantOrderId']);
      if (!isset($order)) {
        $message = "The Order couldn't be found or created";
        echo $message;
        exit();
      }

      if (!$this->_objectManager->get(\Magento\Checkout\Model\Session\SuccessValidator::class)->isValid()) {
        return $this->resultRedirectFactory->create()->setPath('checkout/cart');
      }

      if ($posted['resultCode'] == '01') {
        $order->setStatus(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT);
        $order->addStatusHistoryComment('Duitku Payment | ' . 'Payment pending' . '| statusCode:' . $posted["resultCode"] . ', reference:' . $posted["reference"]);
        $order->save();
        return $this->resultRedirectFactory->create()->setPath('duitkupop/index/pending');
      } else if ($posted['resultCode'] == '02') {
        $order->setStatus(\Magento\Sales\Model\Order::STATE_CANCELED);
        $order->addStatusToHistory(\Magento\Sales\Model\Order::STATE_CANCELED);
        $order->addStatusHistoryComment('Duitku Payment | ' . 'Payment failed' . ' | statusCode:' . $posted["resultCode"] . ', reference:' . $posted["reference"]);
        $order->save();
        $order->getPayment()->cancel();
        $order->registerCancellation();
        $this->_messageManager->addError(__('Your payment failed, and order has been canceled.'));
        return $this->resultRedirectFactory->create()->setPath('checkout/onepage/failure');
      } else if ($posted['resultCode'] == '00') {
        $config = $om->get('Magento\Framework\App\Config\ScopeConfigInterface');

        $endpoint = $config->getValue('payment/duitkupop/url_endpoint', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $apiKey = $config->getValue('payment/duitkupop/api_key', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $merchantCode = $config->getValue('payment/duitkupop/merchant_code', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $merchantOrderId = $posted['merchantOrderId'];
        $signature = md5($merchantCode . $merchantOrderId . $apiKey);
        $url = $endpoint . '/api/merchant/transactionStatus';
        $params = array(
          'merchantCode' => $merchantCode,
          'merchantOrderId' => $merchantOrderId,
          'signature' => $signature
        );

        if (extension_loaded('curl')) {
          try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
              'Content-Type: application/json'
            ));
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
            // Receive server response ...
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $server_output = curl_exec($ch);
            curl_close($ch);

            $respondStatus = json_decode($server_output);

            if ($respondStatus->statusCode == '00' && $posted['resultCode'] == '00') {
              if ($order->canInvoice() && !$order->hasInvoices()) {
                $invoice = $this->_objectManager->create('Magento\Sales\Model\Service\InvoiceService')->prepareInvoice($order);
                $invoice->register();
                $invoice->save();
                $invoice->pay();
                $transactionSave = $this->_objectManager->create('Magento\Framework\DB\Transaction')
                  ->addObject($invoice)
                  ->addObject($invoice->getOrder());
                $transactionSave->save();
              }

              $order->setData('state', 'processing');
              $order->setStatus(\Magento\Sales\Model\Order::STATE_PROCESSING);
              $order->addStatusToHistory(\Magento\Sales\Model\Order::STATE_PROCESSING);

              $order->addStatusHistoryComment('Duitku Payment | ' . 'Payment Success' . ' | statusCode:' . $posted["resultCode"] . ', reference:' . $posted["reference"]);
              $order->save();
              return $this->resultRedirectFactory->create()->setPath('checkout/onepage/success');
            } else {
              return $this->resultRedirectFactory->create()->setPath('checkout/onepage/failure');
            }
          } catch (Exception $e) {
            error_log($e->getMessage());
            echo $e->getMessage();
          }
        } else {
          throw new Exception("Duitku payment need curl extension, please enable curl extension in your web server");
        }
      } else {
        return $this->resultRedirectFactory->create()->setPath('checkout/cart');
      }
    } catch (\Throwable $th) {
      // error_log($e->getMessage());
      echo $th;
    }
  }
}
