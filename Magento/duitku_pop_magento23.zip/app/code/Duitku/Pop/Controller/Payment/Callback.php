<?php

namespace Duitku\Pop\Controller\Payment;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Controller\ResultFactory;

class Callback extends \Magento\Framework\App\Action\Action
{
    protected $_checkoutSession;
    protected $_logger;
    protected $_coreSession;
    protected $_resultJsonFactory;

    public function __construct(\Magento\Framework\App\Action\Context $context, \Magento\Framework\Session\SessionManagerInterface $coreSession, \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)
    {
        parent::__construct($context);
        $this->_coreSession = $coreSession;
        $this->_resultJsonFactory = $resultJsonFactory;
    }

    public function execute()
    {
        try {
            $message = '';
            $posted = $this->getRequest()->getParams();
            $om = $this->_objectManager;

            if (empty($posted['merchantOrderId']) || empty($posted['resultCode']) || empty($posted['reference'])) {
                $message = "Parameteres are missing. Request: " . json_encode($posted);
                $responseCode = Exception::HTTP_BAD_REQUEST;
                $result = $this->_resultJsonFactory->create();
                $result->setHttpResponseCode($responseCode);
                $result->setData(
                    [
                        'statusCode' => $responseCode,
                        'message' => $message
                    ]
                );

                return $result;
            }

            $order = $om->get('Magento\Sales\Model\Order')->load($posted['merchantOrderId']);
            if (!isset($order)) {
                $responseCode = Exception::HTTP_BAD_REQUEST;
                $message = "The Order couldn't be found or created";
                $result = $this->_resultJsonFactory->create();
                $result->setHttpResponseCode($responseCode);
                $result->setData(
                    [
                        'statusCode' => $responseCode,
                        'message' => $message
                    ]
                );
                return $result;
            }

            $config = $om->get('Magento\Framework\App\Config\ScopeConfigInterface');

            $endpoint = $config->getValue('payment/duitkupop/url_endpoint', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $apiKey = $config->getValue('payment/duitkupop/api_key', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $merchantCode = $config->getValue('payment/duitkupop/merchant_code', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $merchantOrderId = $posted['merchantOrderId'];
            $signature = md5($merchantCode . $merchantOrderId . $apiKey);
            $url = $endpoint . '/api/merchant/transactionStatus';
            $params = array(
                'merchantCode' => $merchantCode,
                'merchantOrderId' => $merchantOrderId,
                'signature' => $signature
            );

            if (extension_loaded('curl')) {
                try {
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/json'
                    ));
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
                    // Receive server response ...
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $server_output = curl_exec($ch);
                    curl_close($ch);

                    $respondStatus = json_decode($server_output);

                    if ($respondStatus->statusCode == '00' && $posted['resultCode'] == '00') {
                        if ($order->canInvoice() && !$order->hasInvoices()) {
                            $invoice = $this->_objectManager->create('Magento\Sales\Model\Service\InvoiceService')->prepareInvoice($order);
                            $invoice->register();
                            $invoice->save();
                            $invoice->pay();
                            $transactionSave = $this->_objectManager->create('Magento\Framework\DB\Transaction')
                                ->addObject($invoice)
                                ->addObject($invoice->getOrder());
                            $transactionSave->save();
                        }

                        $order->setData('state', 'processing');
                        $order->setStatus(\Magento\Sales\Model\Order::STATE_PROCESSING);
                        $order->addStatusToHistory(\Magento\Sales\Model\Order::STATE_PROCESSING);

                        $order->addStatusHistoryComment('Duitku Payment | ' . 'Payment Success' . ' | statusCode:' . $posted["resultCode"] . ', reference:' . $posted["reference"]);
                        $order->save();
                        $responseCode = Response::HTTP_OK;
                        $message = 'Duitku Payment | ' . 'Payment Success & Callback Success' . ' | statusCode:' . $posted["resultCode"] . ', reference:' . $posted["reference"];
                        $result = $this->_resultJsonFactory->create();
                        $result->setHttpResponseCode($responseCode);
                        $result->setData(
                            [
                                'statusCode' => $responseCode,
                                'message' => $message
                            ]
                        );
                        return $result;
                    } else {
                        $order->setStatus(\Magento\Sales\Model\Order::STATE_CANCELED);
                        $order->addStatusToHistory(\Magento\Sales\Model\Order::STATE_CANCELED);
                        $order->addStatusHistoryComment('Duitku Payment | ' . 'Payment failed & Callback failed' . ' | statusCode:' . $posted["resultCode"] . ', reference:' . $posted["reference"]);
                        $order->save();
                        $order->getPayment()->cancel();
                        $order->registerCancellation();
                        $responseCode = Exception::HTTP_INTERNAL_ERROR;
                        $message = 'Duitku Payment | ' . 'Payment failed & Callback failed' . ' | statusCode:' . $posted["resultCode"] . ', reference:' . $posted["reference"];
                        $result = $this->_resultJsonFactory->create();
                        $result->setHttpResponseCode($responseCode);
                        $result->setData(
                            [
                                'statusCode' => $responseCode,
                                'message' => $message
                            ]
                        );
                        return $result;
                    }
                } catch (Exception $e) {
                    error_log($e->getMessage());
                    $responseCode = Exception::HTTP_INTERNAL_ERROR;
                    $message = $e->getMessage();
                    $result = $this->_resultJsonFactory->create();
                    $result->setHttpResponseCode($responseCode);
                    $result->setData(
                        [
                            'statusCode' => $responseCode,
                            'message' => $message
                        ]
                    );
                    return $result;
                }
            } else {
                $responseCode = Exception::HTTP_INTERNAL_ERROR;
                $message = "Duitku payment need curl extension, please enable curl extension in your web server";
                $result = $this->_resultJsonFactory->create();
                $result->setHttpResponseCode($responseCode);
                $result->setData(
                    [
                        'statusCode' => $responseCode,
                        'message' => $message
                    ]
                );
                return $result;
            }

        } catch (\Throwable $th) {
            echo $th;
        }
    }
}
