<?php

namespace Duitku\Pop\Controller\Payment;
class Index extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        echo '<p>Duitku Payment Plugin Magento 2.3 CMS</p>';
    }
}
