<?php

namespace Duitku\Pop\Controller\Payment;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\View\Element\Messages;

class Cancel extends \Magento\Framework\App\Action\Action
{
  protected $_checkoutSession;
  protected $_logger;
  protected $_coreSession;

  public function __construct(\Magento\Framework\App\Action\Context $context, \Magento\Framework\Session\SessionManagerInterface $coreSession, \Magento\Framework\Message\ManagerInterface $messageManager)
  {
    parent::__construct($context);
    $this->_coreSession = $coreSession;
    $this->_messageManager = $messageManager;
  }

  public function execute()
  {
    $posted = $this->getRequest()->getParams();
    $om = $this->_objectManager;
    $session = $om->get('Magento\Checkout\Model\Session');
    $quote2 = $session->getLastRealOrder();
    $orderId = $quote2->getIncrementId();
    $order = $om->get('Magento\Sales\Model\Order')->loadByIncrementId($orderId);
    if ($order->getState() == \Magento\Sales\Model\Order::STATE_NEW) {
      $order->setStatus(\Magento\Sales\Model\Order::STATE_CANCELED);
      $order->addStatusToHistory(\Magento\Sales\Model\Order::STATE_CANCELED);
      $order->addStatusHistoryComment('Duitku Payment | ' . 'Pop up Payment close - ' . 'by User | statusCode:' . $_GET["resultCode"] . ', reference:' . $_GET["reference"]);
      $order->save();
      $order->getPayment()->cancel();
      $order->registerCancellation();
      if ($posted['resultCode'] == '02') {
        $this->_messageManager->addError(__('Your payment failed, and order has been canceled.'));
        return $this->resultRedirectFactory->create()->setPath('checkout/onepage/failure');
      } else {
        return $this->resultRedirectFactory->create()->setPath('duitkupop/index/close');
      }
    } else {
      return $this->resultRedirectFactory->create()->setPath('checkout/cart');
    }
  }
}
