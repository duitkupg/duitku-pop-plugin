define(
  [
    'Magento_Checkout/js/view/payment/default',
    'jquery',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/url-builder',
    'mage/storage',
    'Magento_Checkout/js/model/error-processor',
    'Magento_Customer/js/model/customer',
    'Magento_Checkout/js/model/full-screen-loader',
    'Duitku_Pop/js/action/set-payment-method',
    'Magento_Checkout/js/model/payment/additional-validators',
    'mage/url',
    'Magento_Ui/js/model/messageList'
  ],
  function (Component, $, quote, urlBuilder, storage, errorProcessor, customer, fullScreenLoader, setPaymentMethodAction, additionalValidators, url, messageList) {
    'use strict';

    return Component.extend({
      defaults: {
        template: 'Duitku_Pop/payment/duitkupop'
      },
      redirectAfterPlaceOrder: false,
      afterPlaceOrder: function () {
        var prod_stat = window.checkoutConfig.payment.duitkupop.production;
        var pop_mode = window.checkoutConfig.payment.duitkupop.popmode;
        if (prod_stat === 1) {
          var lib_src = "https://app-prod.duitku.com/lib/js/duitku.js";
        } else {
          var lib_src = "https://app-sandbox.duitku.com/lib/js/duitku.js";
        }
        var libScript = document.createElement('script');
        libScript.src = lib_src;
        document.body.appendChild(libScript);

        $.ajax({
          type: 'post',
          url: url.build('duitkupop/payment/redirect'),
          cache: false,
          success: function (data) {
            if (pop_mode === '1') {
              var countExecute = 0;
              var checkoutExecuted = false;
              var intervalFunction = 0;
              var reference = data.reference !== undefined ? data.reference : "";
              function executeCheckout() {
                intervalFunction = setInterval(function () {
                  try {
                    checkout.process(reference, {
                      successEvent: function (result) {
                        messageList.addSuccessMessage({
                          message: result.resultCode === "00" ? "Payment Success" : "Seems problem in your payment"
                        });
                        window.location.replace(url.build('duitkupop/payment/notify?merchantOrderId=' + result.merchantOrderId + '&resultCode=' + result.resultCode + '&reference=' + result.reference));
                      },
                      pendingEvent: function (result) {
                        messageList.addSuccessMessage({
                          message: result.resultCode === "01" ? "Payment Pending" : "Seems problem in your payment"
                        });
                        window.location.replace(url.build('duitkupop/payment/notify?merchantOrderId=' + result.merchantOrderId + '&resultCode=' + result.resultCode + '&reference=' + result.reference));
                      },
                      errorEvent: function (result) {
                        messageList.addErrorMessage({
                          message: result.resultCode
                        });
                        window.location.replace(url.build('duitkupop/payment/cancel?merchantOrderId=' + result.merchantOrderId + '&resultCode=' + result.resultCode + '&reference=' + result.reference));
                      },
                      closeEvent: function (result) {
                        messageList.addErrorMessage({
                          message: 'Your order has been canceled, because you close payment page. Thank you'
                        });
                        window.location.replace(url.build('duitkupop/payment/cancel?merchantOrderId=' + result.merchantOrderId + '&resultCode=' + result.resultCode + '&reference=' + result.reference));
                      }
                    });
                    var checkoutExecuted = true;
                  } catch (e) {
                    countExecute++;
                    if (countExecute >= 10) {
                      messageList.addErrorMessage({
                        message: 'Reload ...'
                      });
                    }
                    console.log(e);
                    console.log("Retrying execute Duitku Payment");
                  } finally {
                    if (checkoutExecuted) {
                      clearInterval(intervalFunction);
                    }
                  }
                }, 1000);
              };
              executeCheckout();
            } else {
              window.location = data.urlPayment;
            }
          }
        });
      }
    });
  }
);
