<?php

namespace Duitku\Pop\Block\Form;

class Duitkupop extends \Magento\Payment\Block\Form
{
  protected $_template = 'form/duitkupop.phtml';
}
