<?php

header('Location: ../../../../');
exit;