<?php

header('Location: ../../../../../');
exit;
