<?php
header('Location: ../../../../../');
exit;