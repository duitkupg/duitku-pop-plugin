<?php

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_'))
  exit;

class DuitkuPop extends PaymentModule
{

  private $_html = '';
  private $_postErrors = array();

  public $duitku_merchant_code;
  public $duitku_api_key;
  public $duitku_endpoint;
  public $duitku_plugin_status;
  public $duitku_expiry_period;
  public $duitku_return_url;
  public $duitku_callback_url;

  public $config_keys;
  public $hooks  = array('payment', 'header', 'backOfficeHeader', 'orderConfirmation', 'paymentReturn');

  public function __construct()
  {
    $this->name = 'duitkupop';
    $this->tab = 'payments_gateways';
    $this->version = '1.0.0';
    $this->author = 'Duitku';
    $this->controllers = array('payment', 'validation');
    $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    $this->bootstrap = true;

    $this->currencies = true;
    $this->currencies_mode = 'checkbox';

    $this->config_keys = array(
      'DUITKU_TITLE',
      'DUITKU_DESCRIPTION',
      'DUITKU_PLUGIN_STATUS',
      'DUITKU_MERCHANT_CODE',
      'DUITKU_API_KEY',
      'DUITKU_ENDPOINT',
      'DUITKU_EXPIRY_PERIOD',
      'DUITKU_UI_MODE',
      'DUITKU_POP_SUCCESS_STATUS',
      'DUITKU_POP_FAILURE_STATUS',
    );

    $config = Configuration::getMultiple($this->config_keys);

    foreach ($this->config_keys as $key) {
      if (isset($config[$key]))
        $this->{strtolower($key)} = $config[$key];
    }

    if (!isset($config['DUITKU_TITLE']))
      Configuration::set('DUITKU_TITLE', "Online Payment via Duitku");
    if (!isset($config['DUITKU_DESCRIPTION']))
      Configuration::set('DUITKU_DESCRIPTION', "Secured by Duitku");
    if (!isset($config['DUITKU_PLUGIN_STATUS']))
      Configuration::set('DUITKU_PLUGIN_STATUS', "sandbox");
    if (!isset($config['DUITKU_UI_MODE']))
      Configuration::set('DUITKU_UI_MODE', "popup");

    parent::__construct();

    $this->displayName = $this->l('Duitku Payment');
    $this->description = $this->l('Accept payments for your products via Duitku payment gateway.');
    $this->confirmUninstall = $this->l('Are you sure about uninstalling Duitku Checkout?');
    if (!count(Currency::checkPaymentCurrencies($this->id)))
      $this->warning = $this->l('No currency has been set for this module.');
  }

  public function install()
  {
    if (!parent::install() || !$this->registerHook('paymentReturn') || !$this->registerHook('paymentOptions')) {
      return false;
    }
    return true;
  }

  public function uninstall()
  {
    if (
      !parent::uninstall() || !Configuration::deleteByName('DUITKU_TITLE') || !Configuration::deleteByName('DUITKU_DESCRIPTION') ||
      !Configuration::deleteByName('DUITKU_MERCHANT_CODE') ||
      !Configuration::deleteByName('DUITKU_API_KEY') ||
      !Configuration::deleteByName('DUITKU_PLUGIN_STATUS') ||
      !Configuration::deleteByName('DUITKU_ENDPOINT') ||
      !Configuration::deleteByName('DUITKU_EXPIRY_PERIOD') ||
      !Configuration::deleteByName('DUITKU_UI_MODE') ||
      !Configuration::deleteByName('DUITKU_POP_SUCCESS_STATUS') ||
      !Configuration::deleteByName('DUITKU_POP_FAILURE_STATUS')
    )
      return false;

    return true;
  }

  private function _postValidation()
  {
    if (Tools::isSubmit('btnSubmit')) {
      if (!Tools::getValue('DUITKU_MERCHANT_CODE')) {
        $this->_postErrors[] = $this->l('Merchant Code is required');
      }
      if (!Tools::getValue('DUITKU_API_KEY')) {
        $this->_postErrors[] = $this->l('API Key is required');
      }
      if (!Tools::getValue('DUITKU_ENDPOINT')) {
        $this->_postErrors[] = $this->l('Endpoint is required');
      }
      if (!Tools::getValue('DUITKU_PLUGIN_STATUS')) {
        $this->_postErrors[] = $this->l('Usage status is required');
      }
    }
  }

  private function _getSession()
  {
    return \PrestaShop\PrestaShop\Adapter\SymfonyContainer::getInstance()->get('session');
  }

  private function _postProcess()
  {
    if (Tools::isSubmit('btnSubmit')) {
      Configuration::updateValue('DUITKU_TITLE', Tools::getValue('DUITKU_TITLE'));
      Configuration::updateValue('DUITKU_DESCRIPTION', Tools::getValue('DUITKU_DESCRIPTION'));
      Configuration::updateValue('DUITKU_PLUGIN_STATUS', Tools::getValue('DUITKU_PLUGIN_STATUS'));
      Configuration::updateValue('DUITKU_MERCHANT_CODE', Tools::getValue('DUITKU_MERCHANT_CODE'));
      Configuration::updateValue('DUITKU_API_KEY', Tools::getValue('DUITKU_API_KEY'));
      Configuration::updateValue('DUITKU_ENDPOINT', Tools::getValue('DUITKU_ENDPOINT'));
      Configuration::updateValue('DUITKU_EXPIRY_PERIOD', Tools::getValue('DUITKU_EXPIRY_PERIOD'));
      Configuration::updateValue('DUITKU_UI_MODE', Tools::getValue('DUITKU_UI_MODE'));
      Configuration::updateValue('DUITKU_POP_SUCCESS_STATUS', Tools::getValue('DUITKU_POP_SUCCESS_STATUS'));
      Configuration::updateValue('DUITKU_POP_FAILURE_STATUS', Tools::getValue('DUITKU_POP_FAILURE_STATUS'));
    }

    $this->_html .= $this->displayConfirmation($this->l('Settings updated'));
  }

  private function _displayDuitkupop()
  {
    return $this->display(__FILE__, 'duitkupop_info.tpl');
  }

  public function getContent()
  {
    if (Tools::isSubmit('btnSubmit')) {
      $this->_postValidation();
      if (!count($this->_postErrors))
        $this->_postProcess();
      else
        foreach ($this->_postErrors as $err)
          $this->_html .= $this->displayError($err);
    } else {
      $this->_html .= '<br />';
    }

    $this->_html .= $this->_displayDuitkupop();
    $this->_html .= $this->renderForm();

    return $this->_html;
  }

  public function hookPaymentOptions($params)
  {
    if (!$this->active) {
      return;
    }

    if (!$this->checkCurrency($params['cart'])) {
      return;
    }

    $this->context->smarty->assign(
      array(
        'DUITKU_DESCRIPTION' =>  $this->l(Configuration::get('DUITKU_DESCRIPTION')),
        'APP_BASE' => __PS_BASE_URI__
      )
    );

    $newOption = new PaymentOption();
    $newOption->setModuleName($this->name)
      ->setCallToActionText(Configuration::get('DUITKU_TITLE'))
      ->setAction($this->context->link->getModuleLink($this->name, 'validation', array(), true))
      ->setAdditionalInformation($this->context->smarty->fetch('module:' . $this->name . '/views/templates/hook/duitkupop_intro.tpl'));
    $payment_options = [
      $newOption,
    ];

    return $payment_options;
  }

  public function checkCurrency($cart)
  {
    $currency_order = new Currency($cart->id_currency);
    $currencies_module = $this->getCurrency($cart->id_currency);

    if (is_array($currencies_module))
      foreach ($currencies_module as $currency_module)
        if ($currency_order->id == $currency_module['id_currency'])
          return true;
    return false;
  }

  public function validateInvoice($reference)
  {
    $uimode = Configuration::get('DUITKU_UI_MODE');
    if ($uimode == 'popup') {
      $redirect_url = $this->context->link->getModuleLink($this->name, 'processcheckout', ['reference_number' => $reference]);
    } else {
      $redirect_url = $reference;
    }
    $data = array(
      "redirect_url" => $redirect_url
    );
    return $data;
  }

  public function warningInvoice($message, $amount)
  {
    $context = Context::getContext();
    $context->cookie->__set("warningMessage", $message);
    $context->cookie->__set("amountMessage", $amount);

    $warning_url = $this->context->link->getModuleLink($this->name, 'warningcheckout');
    $data = array(
      "warning_url" => $warning_url
    );

    return $data;
  }

  public function statusTransaction($respond)
  {
    $objOrder = new Order($respond->merchantOrderId);

    if ($objOrder) {
      $history = new OrderHistory();
      $history->id_order = (int)$objOrder->id;
      if ($respond->statusCode == '00') {
        $history->changeIdOrderState(Configuration::get('DUITKU_POP_SUCCESS_STATUS'), (int)($objOrder->id));
        $history->addWithemail(true);
      } else if ($respond->statusCode == '02') {
        $history->changeIdOrderState(Configuration::get('DUITKU_POP_FAILURE_STATUS'), (int)($objOrder->id));
        $history->addWithemail(true);
      }
    }

    $return_url = $this->context->link->getModuleLink($this->name, 'return', ['merchantOrderId' => $respond->merchantOrderId, 'statusCode' => $respond->statusCode, 'reference' => $respond->reference]);
    $data = array(
      "return_url" => $return_url
    );
    return $data;
  }

  public function renderForm()
  {
    $order_states = array();
    foreach (OrderState::getOrderStates($this->context->language->id) as $state) {
      array_push(
        $order_states,
        array(
          'id_option' => $state['id_order_state'],
          'name' => $state['name']
        )
      );
    }

    $fields_form = array(
      'form' => array(
        'legend' => array(
          'title' => $this->l('Duitku Payment Configuration'),
          'icon' => 'icon-cogs'
        ),
        'input' => array(
          array(
            'type' => 'text',
            'label' => 'Payment Title',
            'name' => 'DUITKU_TITLE',
            'desc' => 'Custom your Payment Title from Duitku'
          ),
          array(
            'type' => 'text',
            'label' => 'Payment Description',
            'name' => 'DUITKU_DESCRIPTION',
            'desc' => 'Custom your Payment Description from Duitku'
          ),
          array(
            'type' => 'select',
            'required' => true,
            'options' => array(
              'query' => $options = array(
                array(
                  'value' => 'sandbox',
                  'label' => 'Sandbox'
                ),
                array(
                  'value' => 'production',
                  'label' => 'Production'
                )
              ),
              'id' => 'value',
              'name' => 'label'
            ),
            'label' => 'Plugin Status',
            'name' => 'DUITKU_PLUGIN_STATUS',
            'desc' => 'Select the plugin usage status'
          ),
          array(
            'type' => 'select',
            'required' => true,
            'options' => array(
              'query' => $options = array(
                array(
                  'value' => 'popup',
                  'label' => 'Popup'
                ),
                array(
                  'value' => 'redirect',
                  'label' => 'Redirect'
                )
              ),
              'id' => 'value',
              'name' => 'label'
            ),
            'label' => 'UI Mode',
            'name' => 'DUITKU_UI_MODE',
            'desc' => 'Select ui mode payment'
          ),
          array(
            'type' => 'text',
            'label' => 'Merchant Code',
            'name' => 'DUITKU_MERCHANT_CODE',
            'required' => true,
            'desc' => 'Get Merchant Code from Duitku'
          ),
          array(
            'type' => 'text',
            'label' => 'API Key',
            'name' => 'DUITKU_API_KEY',
            'required' => true,
            'desc' => 'Get API Key from Duitku'
          ),
          array(
            'type' => 'text',
            'label' => 'Endpoint URL',
            'name' => 'DUITKU_ENDPOINT',
            'required' => true,
            'desc' => 'Get Endpoint URL from Duitku'
          ),
          array(
            'type' => 'text',
            'label' => 'Expiry Period',
            'name' => 'DUITKU_EXPIRY_PERIOD',
            'desc' => 'The validity period of the transaction before it expires. (e.g 1 - 1440 ( min ))'
          ),
          array(
            'type' => 'select',
            'label' => 'Map payment SUCCESS status to:',
            'name' => 'DUITKU_POP_SUCCESS_STATUS',
            'required' => true,
            'options' => array(
              'query' => $order_states,
              'id' => 'id_option',
              'name' => 'name'
            ),
          ),
          array(
            'type' => 'select',
            'label' => 'Map payment FAILURE status to:',
            'name' => 'DUITKU_POP_FAILURE_STATUS',
            'required' => true,
            'options' => array(
              'query' => $order_states,
              'id' => 'id_option',
              'name' => 'name'
            ),
          ),
        ),
        'submit' => array(
          'title' => $this->l('Save Configuration'),
        )
      ),
    );

    $helper = new HelperForm();
    $helper->show_toolbar = false;
    $helper->table = $this->table;
    $lang = new Language((int) Configuration::get('PS_LANG_DEFAULT'));
    $helper->default_form_language = $lang->id;
    $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
    $this->fields_form = array();
    $helper->id = (int) Tools::getValue('id_carrier');
    $helper->identifier = $this->identifier;
    $helper->submit_action = 'btnSubmit';
    $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) . '&configure='
      . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
    $helper->token = Tools::getAdminTokenLite('AdminModules');
    $helper->tpl_vars = array(
      'fields_value' => $this->getConfigFieldsValues(),
      'languages' => $this->context->controller->getLanguages(),
      'id_language' => $this->context->language->id
    );

    return $helper->generateForm(array($fields_form));
  }

  public function getConfigFieldsValues()
  {
    return array(
      'DUITKU_MERCHANT_CODE' => Tools::getValue('DUITKU_MERCHANT_CODE', Configuration::get('DUITKU_MERCHANT_CODE')),
      'DUITKU_API_KEY' => Tools::getValue('DUITKU_API_KEY', Configuration::get('DUITKU_API_KEY')),
      'DUITKU_ENDPOINT' => Tools::getValue('DUITKU_ENDPOINT', Configuration::get('DUITKU_ENDPOINT')),
      'DUITKU_PLUGIN_STATUS' => Tools::getValue('DUITKU_PLUGIN_STATUS', Configuration::get('DUITKU_PLUGIN_STATUS')),
      'DUITKU_TITLE' => Tools::getValue('DUITKU_TITLE', Configuration::get('DUITKU_TITLE')),
      'DUITKU_DESCRIPTION' => Tools::getValue('DUITKU_DESCRIPTION', Configuration::get('DUITKU_DESCRIPTION')),
      'DUITKU_EXPIRY_PERIOD' => Tools::getValue('DUITKU_EXPIRY_PERIOD', Configuration::get('DUITKU_EXPIRY_PERIOD')),
      'DUITKU_UI_MODE' => Tools::getValue('DUITKU_UI_MODE', Configuration::get('DUITKU_UI_MODE')),
      'DUITKU_POP_SUCCESS_STATUS' => Tools::getValue('DUITKU_POP_SUCCESS_STATUS', Configuration::get('DUITKU_POP_SUCCESS_STATUS')),
      'DUITKU_POP_FAILURE_STATUS' => Tools::getValue('DUITKU_POP_FAILURE_STATUS', Configuration::get('DUITKU_POP_FAILURE_STATUS')),
    );
  }
}
