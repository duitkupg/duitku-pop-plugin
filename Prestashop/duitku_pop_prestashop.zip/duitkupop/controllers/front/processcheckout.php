<?php

session_start();

class DuitkuPopProcesscheckoutModuleFrontController extends ModuleFrontController {
  public $ssl = true;

  public function initContent(){
    $this->display_column_left = false;
    $this->display_column_right = false;
    parent::initContent();

    $moduleReturnUrl = $this->context->link->getModuleLink('duitkupop','status');
    $plugin_status = Configuration::get('DUITKU_PLUGIN_STATUS');
    $endpoint = Configuration::get('DUITKU_ENDPOINT');

    if ($plugin_status == 'sandbox') {
      $url_lib = 'https://app-sandbox.duitku.com/lib/js/duitku.js';
    }elseif ($plugin_status == 'production') {
      $url_lib = 'https://app-prod.duitku.com/lib/js/duitku.js';
    }

    $this->context->smarty->assign(array(
      'merchantOrderId' => $cart->id,
      'library_url' => $url_lib,
      'referenceNumber' => $_GET['reference_number'],
      'this_path' => $this->module->getPathUri(),
      'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->module->name.'/',
      'shop_url' => __PS_BASE_URI__,
      'moduleReturnUrl' => $moduleReturnUrl,
      'cms_version' => _PS_VERSION_,
    ));

    $this->setTemplate('module:duitkupop/views/templates/front/processcheckout.tpl');
  }
}
