<?php

class DuitkuPopStatusModuleFrontController extends ModuleFrontController
{
  public $ssl = true;
  public $display_column_left = false;
  public function initContent()
  {
    parent::initContent();

    $duitkupop = new DuitkuPop();
    $merchantcode = Configuration::get('DUITKU_MERCHANT_CODE');
    $apikey = Configuration::get('DUITKU_API_KEY');
    $endpoint = Configuration::get('DUITKU_ENDPOINT');
    $url = $endpoint . '/api/merchant/transactionStatus';

    if (!empty($_GET['notify']) && $_GET['notify'] === 'callback') {
      $orderId = $_POST['merchantOrderId'];
      $signature = md5($merchantcode . $orderId . $apikey);
      $params = array(
        'merchantCode' => $merchantcode,
        'merchantOrderId' => $orderId,
        'signature' => $signature
      );
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json'
      ));
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));

      // Receive server response ...
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

      $server_output = curl_exec($ch);

      curl_close($ch);

      $respondStatus = json_decode($server_output);

      $url_respond = $duitkupop->statusTransaction($respondStatus);

      Tools::redirectLink($url_respond['return_url']);
    } else {
      if ($_GET['resultCode'] == '00') {
        $orderId = $_GET['merchantOrderId'];
        $signature = md5($merchantcode . $orderId . $apikey);
        $params = array(
          'merchantCode' => $merchantcode,
          'merchantOrderId' => $orderId,
          'signature' => $signature
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'Content-Type: application/json'
        ));
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));

        // Receive server response ...
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $server_output = curl_exec($ch);

        curl_close($ch);

        $respondStatus = json_decode($server_output);

        $url_respond = $duitkupop->statusTransaction($respondStatus);

        Tools::redirectLink($url_respond['return_url']);
      } else {
        $objectParam = new stdClass();
        $objectParam->statusCode = isset($_GET['resultCode']) ? $_GET['resultCode'] : null;
        $objectParam->merchantOrderId = isset($_GET['merchantOrderId']) ? $_GET['merchantOrderId'] : null;
        $objectParam->reference = isset($_GET['reference']) ? $_GET['reference'] : null;
        $url_respond = $duitkupop->statusTransaction($objectParam);
        Tools::redirectLink($url_respond['return_url']);
      }
    }
  }
}
