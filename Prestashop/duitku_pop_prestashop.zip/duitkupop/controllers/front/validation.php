<?php

class DuitkuPopValidationModuleFrontController extends ModuleFrontController
{

  public function postProcess()
  {
    $cart = $this->context->cart;
    $currency = $this->context->currency;
    $customer = new Customer($cart->id_customer);
    if (!Validate::isLoadedObject($customer) || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active)
      Tools::redirect('index.php?controller=order&step=1');

    $authorized = false;
    foreach (Module::getPaymentModules() as $module)
      if ($module['name'] == 'duitkupop') {
        $authorized = true;
        break;
      }
    if (!$authorized)
      die($this->module->l('This payment method is not available.', 'validation'));

    $customer = new Customer($cart->id_customer);
    if (!Validate::isLoadedObject($customer))
      Tools::redirect('index.php?controller=order&step=1');
    $domain = Tools::getShopDomainSsl(true, true);
    $merchantcode = Configuration::get('DUITKU_MERCHANT_CODE');
    $apikey = Configuration::get('DUITKU_API_KEY');
    $endpoint = Configuration::get('DUITKU_ENDPOINT');
    $expiry_period = Configuration::get('DUITKU_EXPIRY_PERIOD');
    $uimode = Configuration::get('DUITKU_UI_MODE');
    $cart_id = $cart->id;
    $amount = $cart->getOrderTotal(true, Cart::BOTH);
    $domain = Tools::getShopDomainSsl(true, true);
    $billing_address = new Address($cart->id_address_invoice);
    $delivery_address = new Address($cart->id_address_delivery);

    $this->module->validateOrder($cart_id, Configuration::get('PS_OS_CHEQUE'), $amount, $this->module->displayName, null, array(), (int)$currency->id, false, $customer->secure_key);

    if (!empty($billing_address->phone_mobile)) {
      $phoneNumber = $billing_address->phone_mobile;
    } elseif (!empty($billing_address->phone)) {
      $phoneNumber = $billing_address->phone;
    }

    $order = Order::getOrderByCartId($cart_id);
    //$signature = md5($merchantcode.(string)$order.(int)$amount.$apikey);

    $tstamp = round(microtime(true) * 1000);
    $mcode = $merchantcode;
    $header_signature = hash('sha256', $mcode . $tstamp . $apikey);

    $params = array(
      'paymentAmount' => (int)$amount,
      'paymentMethod' => '',
      'expiryPeriod' => (int)$expiry_period,
      'callbackUrl' => $domain . __PS_BASE_URI__ . 'index.php?fc=module&module=duitkupop&controller=status?notify=callback',
      'returnUrl' => $domain . __PS_BASE_URI__ . 'index.php?fc=module&module=duitkupop&controller=status',
      'merchantOrderId' => (string)$order,
      'productDetails' => 'Order ' . $order,
      'additionalParam' => (string)$cart->id,
      'merchantUserInfo' => $customer->email,
      'email' => $customer->email,
      'phoneNumber' => $phoneNumber,
    );

    $params_customer_details = array(
      'firstName' => $billing_address->firstname,
      'lastName' => $billing_address->lastname,
      'email' => $customer->email,
      'phoneNumber' => $phoneNumber,
    );

    if (!empty($billing_address->address2)) {
      $address_bill = $billing_address->address1 . ', ' . $billing_address->address2;
    } else {
      $address_bill = $billing_address->address1;
    }

    $params_billing_address = array(
      'firstName' => $billing_address->firstname,
      'lastName' => $billing_address->lastname,
      'address' => $address_bill,
      'city' => $billing_address->city,
      'postalCode' => $billing_address->postcode,
      'phone' => $phoneNumber,
      'countryCode' => 'ID'
    );

    if ($cart->id_address_delivery != $cart->id_address_invoice) {
      if (!empty($delivery_address->address2)) {
        $address_deliv = $delivery_address->address1 . ', ' . $delivery_address->address2;
      } else {
        $address_deliv = $delivery_address->address1;
      }

      if (!empty($delivery_address->phone_mobile)) {
        $phoneNumberDeliv = $delivery_address->phone_mobile;
      } elseif (!empty($delivery_address->phone)) {
        $phoneNumberDeliv = $delivery_address->phone;
      }

      $params_delivery_address = array(
        'firstName' => $delivery_address->firstname,
        'lastName' => $delivery_address->lastname,
        'address' => $address_deliv,
        'city' => $delivery_address->city,
        'postalCode' => $delivery_address->postcode,
        'phone' => $phoneNumberDeliv,
        'countryCode' => 'ID'
      );
    } else {
      $params_delivery_address = $params_billing_address;
    }

    $products = $cart->getProducts();
    $params_item_details = array();
    $shipping_fee = $cart->getTotalShippingCost();
    $discount = -1 * $cart->getOrderTotal(true, Cart::ONLY_DISCOUNTS);

    foreach ($products as $aProduct) {
      $params_item_details[] = array(
        "price" =>  (int)($aProduct['price_wt'] * (int)$aProduct['cart_quantity']),
        "quantity" => (int)$aProduct['cart_quantity'],
        "name" => $aProduct['name']
      );
    }

    if ($discount !== 0) {
      $params_item_details[] = array(
        "price" =>  $discount,
        "quantity" => 1,
        "name" => "Coupon"
      );
    }

    if ($shipping_fee > 0) {
      $params_item_details[] = array(
        "price" =>  (int)($shipping_fee),
        "quantity" => 1,
        "name" => "Shipping fee"
      );
    }

    $params_customer_details['billingAddress'] = $params_billing_address;
    $params_customer_details['shippingAddress'] = $params_delivery_address;
    $params['customerDetail'] = $params_customer_details;
    $params['itemDetails'] = $params_item_details;

    // $redirect_url= $this->context->link->getModuleLink($this->name, 'payment',['referenceNumber' => 'nomornya']);
    //
    // echo '<pre>' . var_export($params, true) . '</pre>';
    // echo '<br/><pre>' . var_export($redirect_url, true) . '</pre>';

    // $duitkucheckout = new DuitkuCheckout();
    // $reference = $duitkucheckout->validationProcess($params);

    $url = $endpoint . '/api/merchant/createInvoice';
    $duitkupop = new DuitkuPop();

    try {
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'x-duitku-signature: ' . $header_signature,
        'x-duitku-timestamp: ' . $tstamp,
        'x-duitku-merchantCode: ' . $mcode
      ));
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));

      // Receive server response ...
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

      $server_output = curl_exec($ch);

      curl_close($ch);

      $respond = json_decode($server_output);

      if ($respond->statusCode == "00") {
        if ($uimode == 'popup') {
          $statRespond = $duitkupop->validateInvoice($respond->reference);
          Tools::redirectLink($statRespond['redirect_url']);
        } else {
          $statRespond = $duitkupop->validateInvoice($respond->paymentUrl);
          Tools::redirectLink($statRespond['redirect_url']);
        }
      } else {
        $message = $duitkupop->warningInvoice($server_output, $amount);
        Tools::redirectLink($message['warning_url']);
      }
    } catch (Exception $e) {
      echo $e->getMessage();
    }
  }
}
