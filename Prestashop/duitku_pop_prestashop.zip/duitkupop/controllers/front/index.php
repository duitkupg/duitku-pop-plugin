<?php
header('Location: ../../../../');
exit;