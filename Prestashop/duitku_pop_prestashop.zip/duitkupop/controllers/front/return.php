<?php

session_start();
class DuitkuPopReturnModuleFrontController extends ModuleFrontController {

  public $ssl = true;

  public function initContent(){
    $this->display_column_left = false;
    $this->display_column_right = right;

    parent::initContent();

    $this->context->smarty->assign(array(
      'merchantOrderId' => $_GET['merchantOrderId'],
      'reference' => $_GET['reference'],
      'statusCode' => $_GET['statusCode'],
      'shop_name' => $this->context->shop->name,
			'this_path' => $this->module->getPathUri(),
    ));

    $this->setTemplate('module:duitkupop/views/templates/front/return.tpl');

  }
}
