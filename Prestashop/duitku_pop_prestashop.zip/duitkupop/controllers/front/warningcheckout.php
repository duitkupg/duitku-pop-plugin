<?php

session_start();

class DuitkuPopWarningcheckoutModuleFrontController extends ModuleFrontController {
  public $ssl = true;

  public function initContent(){
    $this->display_column_left = false;
    $this->display_column_right = false;
    parent::initContent();
    $message = $this->context->cookie->warningMessage; 
    $amount = $this->context->cookie->amountMessage; 
    
    $moduleReturnUrl = $this->context->link->getModuleLink('duitkupop','status');

    $this->context->smarty->assign(array(
      'messageWarning' => $message,
      'messageAmount' => $amount,
      'this_path' => $this->module->getPathUri(),
      'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->module->name.'/',
      'shop_url' => __PS_BASE_URI__,
      'moduleReturnUrl' => $moduleReturnUrl,
      'cms_version' => _PS_VERSION_,
    ));

    $this->setTemplate('module:duitkupop/views/templates/front/warningcheckout.tpl');
  }
}
