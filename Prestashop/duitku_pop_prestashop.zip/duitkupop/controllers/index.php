<?php
header('Location: ../../../');
exit;