<?php
		
header("Location: ../");
exit;