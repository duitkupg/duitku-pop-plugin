<?php
/*
Plugin Name: Duitku Pop Payment Gateway
Plugin URI: https://github.com/duitkupg/duitku-pop-plugin/
Description: Duitku Payment Gateway with a Pop Up view
Version: 1.0.0
Author: Duitku
Author URI: https://www.duitku.com/
License: ...
WC requires at least: ..
WC tested up to: ..
*/

add_action( 'plugins_loaded', 'duitku_pop_init', 0 );

function duitku_pop_init() {

  if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
    return;
  }

  require_once dirname( __FILE__ ) . '/class/class.duitku-pop.php';
  add_filter( 'woocommerce_payment_gateways', 'add_duitku_pop' );
}

function add_duitku_pop( $methods ) {
  $methods[] = 'WC_Gateway_Duitku_Pop';
  return $methods;
}
