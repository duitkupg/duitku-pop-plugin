=== Duitku Pop Payment Gateway ===
/*
Plugin Name:  Duitku Pop Payment Gateway
Plugin URI:   https://github.com/duitkupg/duitku-pop-plugin/
Description:  Duitku Payment Gateway with a Pop Up view 
Version:      1.0.0
Author:       Duitku Development Team
Contributors: anggiyawanduitku, heripurnama, rayhanduitku
Author URI:   http://duitku.com
Tags:         paymentgateway, duitku, BCA, Mandiri, BRI, CIMB, BNI, OVO, Shopee, LinkAja, Dana
Requires at least: 4.7
Tested up to: 5.8.3
Stable tag: 1.0.0
Requires PHP: 7.0
Author URI:   http://duitku.com
License:      GPLv2 or Later
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
*/

== Description ==

Do you want the best solution to accept Credit Cards, e-wallet, and Various Bank Transfers on your website? Our Payment Gateway for WooCommerce plugin integrates with your WooCommerce store and lets you accept those payments through our payment gateway.
Securely accept major credit cards, View and manage transactions from one convenient place – your Duitku dashboard.

Supported Payment Channels :

1.	Credit Card Aggregator full-payment (Visa, Master, JCB)
2.	Credit Card Facilitator installment and full-payment (Visa, Master, JCB, AMEX)
3.	BCA KlikPay
4.	BCA Virtual Account
5.	Mandiri Virtual Account (Deprecated)
6.	Mandiri Virtual Account
7.	Permata Bank Virtual Account
8.	ATM Bersama
9.	CIMB Niaga Virtual Account
10.	BNI Virtual Account
11.	Maybank Virtual Account
12.	Retail (Alfamart,  Pegadaian and Pos Indonesia)
13.	OVO
14.	Indodana Paylater
15.	Shopee Pay
16.	Shopee Pay Apps
17.	Bank Artha Graha
18.	Bank Sahabat Sampoerna
19.	LinkAja Apps (Percentage Fee)
20.	LinkAja Apps (Fixed Fee)
21.	DANA
22.	LinkAja QRIS
23.	Indomaret
24.	PosPay
24.	BRIVA

== Installation ==

Guide to installing the Duitku plugin for Woocommerce

1. Download the Duitku plugin for Woocommerce here .

2. Open your Wordpress Admin menu (generally in / wp-admin).

3. Open the Plugins menu -> Add New Page.

4. Upload the Duitku plugin file (Make sure Woocommerce is installed before adding the Duitku plugin).

5. After the plugin is installed, Duitku will appear in the list of installed plugins. Open the Plugin -> Installled Plugins page, then activate the Duitku plugin.

6. At the Installed Plugins page you may see Duitku plugin on the list.

7. Open Woocommerce -> Settings page.

8. Then select the 'Payment' tab.

9. Select "Duitku Payment" and click Manage.

10. Enter the merchant code and API Key. These parameters are created on the Duitku merchant page in the My Projects menu section. Click Save after finished.
    Information:
        Plugin Status: select 'Sandbox' as development usage or 'Production' for live usage. You need to set Plugin Status as like as URL Endpoint that you want to use.
        UI Mode: you can choose between Pop-up payment user interface or Redirection payment user interface.
        Duitku Merchant Code: enter your merchant code that you get from project on the Duitku merchant page.
        Duitku API Key: enter the project API key that you got from Project on the Duitku merchant page.
        URL Endpoint:
            If integration is still in the development stage, use this address:
                https://api-sandbox.duitku.com
            If the integration is in production stage, use this address:
                https://api-prod.duitku.com
        Expiry Period: The validity period of the transaction before it expires. Value input is an integer between 1 - 1440 counted as minutes.

== Frequently Asked Questions ==

= What is Duitku? =

Duitku is a Payment Solution service with the best MDR (Merchant Discount Rate) fees from many Payment Channels in Indonesia. As your payment service provider, Duitku can serve payments via credit cards, bank transfers and internet banking directly to your online shop.

= How do I integrate Duitku with my website? =

Integrating online payments with Duitku is very easy, web integration using our API. (API doc: http://docs.duitku.com/docs-api.html) or using plugins for e-commerce.

== Screenshots ==

1. Checkout Page

2. Payment Page

3. Payment Page Detail Request

4. Payment Page Payment Channel list

5. Payment Page Detail Transaction

6. Payment Page Pending

7. Payment Page Success

8. Duitku Pop Configuration

9. Duitku Business Flow

10. Duitku System Flow

== Changelog ==
= 1.0 =

Initial Public Release