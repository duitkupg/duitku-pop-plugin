<?php

global $woocommerce;

$order = new WC_Order( $order_id );

?>
<h2 class="duitku_payment_info">Payment Info</h2>
<table class="woocommerce-table shop_table">
  <tbody>
    <tr>
      <td>
        Reference Number :
      </td>
      <td>
        <?php esc_html_e($order->get_meta('_duitku_reference_number'), "wc_duitku");?>
      </td>
    </tr>
    <tr>
      <td>
        Transaction Status :
      </td>
      <td>
        <?php
          $transactionStatus = "";
          if ($order->get_meta('_duitku_result_code') == "01") {
            $transactionStatu = "Transaction Pending";
          }elseif ($order->get_meta('_duitku_result_code') == "00") {
            // $order->payment_complete();
            wc_add_notice('Pembayaran dengan duitku telah berhasil.', 'success');
            $transactionStatu = "Transaction Success";
          }
          esc_html_e($transactionStatu, "wc_duitku");
        ?>
      </td>
    </tr>
  </tbody>
</table>
<?php
if ($order->get_meta('_duitku_result_code') == "01") {
  esc_html_e( "<span>Please complete your payment as instructed before. Check your email for instruction. Thank You!</span>", "wc_duitku");
}
?>

<script type="text/javascript">
  setTimeout(function(){
    document.querySelectorAll('.duitku_payment_info')[0].scrollIntoView();
  }, 888);
</script>
