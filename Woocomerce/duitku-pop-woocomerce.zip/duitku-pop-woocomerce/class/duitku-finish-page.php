<?php

global $woocommerce;

$order = new WC_Order( $order_id );

?>
<h2 class="duitku_payment_info">Payment Info</h2>
<table class="woocommerce-table shop_table">
  <tbody>
    <tr>
      <td>
        Reference Number :
      </td>
      <td>
        <?php echo $order->get_meta('_duitku_reference_number');?>
      </td>
    </tr>
    <tr>
      <td>
        Transaction Status :
      </td>
      <td>
        <?php
        if ($order->get_meta('_duitku_result_code') == "01") {
          echo "Transaction Pending";
        }elseif ($order->get_meta('_duitku_result_code') == "00") {
          // $order->payment_complete();
          wc_add_notice('Pembayaran dengan duitku telah berhasil.', 'success');
          echo "Transaction Success";
        }
        ?>
      </td>
    </tr>
  </tbody>
</table>
<?php
if ($order->get_meta('_duitku_result_code') == "01") {
  echo "<span>Please complete your payment as instructed before. Check your email for instruction. Thank You!</span>";
}
?>

<script type="text/javascript">
  setTimeout(function(){
    document.querySelectorAll('.duitku_payment_info')[0].scrollIntoView();
  }, 888);
</script>
