<?php
include_once dirname(__FILE__) . '/../includes/duitku/wc-gateway-duitku-sanitized.php';
include_once dirname(__FILE__) . '/../includes/duitku/wc-gateway-duitku-validation.php';

class WC_Gateway_Duitku_Pop extends WC_Payment_Gateway
{
  /** @var bool whether or not logging is enabled */
  public static $log_enabled = false;

  /** @var WC_Logger Logger instance */
  public static $log = false;

  /** you can control it with Sanitized (default: true) */
  public static $sanitized = true;
  public static $validation = true;
	
  function __construct()
  {

    $this->id           = 'duitku_pop';
    // $this->icon         = apply_filters( 'woocommerce_duitku_icon', '' );
    $this->icon = plugins_url('/assets/logo.png', dirname(__FILE__));
    $this->method_title = __('Duitku Payment', 'woocommerce');
    $this->has_fields   = true;
    $this->payment_method     = '';
    $this->redirect_url = WC()->api_request_url('WC_Gateway_' . $this->id);

    $this->init_form_fields();
    $this->init_settings();

    $this->title              = $this->get_option('title');
    $this->description        = $this->get_option('description');
    $this->apiKey             = $this->get_option('duitku_api_key');
    $this->merchantCode       = $this->get_option('duitku_merchant_code');
    $this->endpoint           = $this->get_option('duitku_endpoint');
    $this->expiryPeriod       = $this->get_option('expiry_period');
    $this->pluginStatus       = $this->get_option('plugin_status');
    $this->uiMode             = $this->get_option('duitku_ui_mode');
    $this->lang               = $this->get_option('duitku_language');
    $this->currency           = $this->get_option('duitku_currency');

    self::$log_enabled = true;

    add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(&$this, 'process_admin_options'));

    add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));

    add_action('woocommerce_thankyou', array($this, 'duitku_finish_page'));

    add_action('woocommerce_api_wc_gateway_duitku_pop', array(&$this, 'duitku_checkout_response'));
  }

  public function admin_options()
  { ?>
    <h3><?php _e('Duitku', 'woocommerce'); ?></h3>
    <p><?php _e('Allows payments using Duitku.', 'woocommerce'); ?></p>
    <table class="form-table">
      <?php
      // Generate the HTML For the settings form. generated from `init_form_fields`
      $this->generate_settings_html();
      ?>
    </table>
    <!--/.form-table-->
  <?php }

  function init_form_fields()
  {

    $this->form_fields = array(
      'enabled' => array(
        'title' => __('Enable/Disable', 'woocommerce'),
        'type' => 'checkbox',
        'label' => __('Enable Duitku Payment', 'woocommerce'),
        'default' => 'yes'
      ),
      'title' => array(
        'title' => __('Title', 'woocommerce'),
        'type' => 'text',
        'description' => __('This controls the title which the user sees during checkout.', 'woocommerce'),
        'default' => __('Online Payment via Duitku', 'woocommerce'),
        'desc_tip'      => true,
      ),
      'description' => array(
        'title' => __('Customer Message', 'woocommerce'),
        'type' => 'textarea',
        'description' => __('This controls the description which the user sees during checkout', 'woocommerce'),
        'default' => ''
      ),
      'plugin_status' => array(
        'title' => __('Plugin Status'),
        'type' => 'select',
        'description' => __('Select the plugin usage status.', 'woocommerce'),
        'required' => true,
        'options' => array(
          'production' => __('Production'),
          'sandbox' => __('Sandbox')
        ),
        'default' => 'sandbox'
      ),
      'duitku_ui_mode' => array(
        'title' => __('UI Mode'),
        'type' => 'select',
        'description' => __('Select ui mode for payment page.', 'woocommerce'),
        'required' => true,
        'options' => array(
          'popup' => __('PopUp'),
          'redirect' => __('Redirect')
        ),
        'default' => 'popup'
      ),
      'duitku_language' => array(
        'title' => __('Language'),
        'type' => 'select',
        'description' => __('Select default language on payment page.', 'woocommerce'),
        'required' => true,
        'options' => array(
          'id' => __('Indonesia'),
          'en' => __('English')
        ),
        'default' => 'id'
      ),
      'duitku_currency' => array(
        'title' => __('Shown Estimation Currency'),
        'type' => 'select',
        'description' => __('Select currency for payment page display. This settings will perform only on <b>Redirect UI</b>.</br> <span style="color:red;">These will only shows estimation rate and not an actual payment amount. Payment Amount is still paid in Indonesian Rupiah.</span>', 'woocommerce'),
        'required' => true,
        'options' => array(
          'idr' => __('-'),
          'usd' => __('USD - United States Dollar'),
          'eur' => __('EUR - Euro')
        ),
        'default' => 'idr'
      ),
      'duitku_merchant_code' => array(
        'title' => __('Merchant Code', 'woocommerce'),
        'type' => 'text',
        'description' => __('Input your Duitku Merchant Code (e.g D0001).', 'woocommerce'),
        'default' => ''
      ),
      'duitku_api_key' => array(
        'title' => __('API Key', 'woocommerce'),
        'type' => 'text',
        'description' => __('Input your Duitku API Key (e.g 732B39FC61796845775D2C4FB05332AF).', 'woocommerce'),
        'default' => ''
      ),
      'duitku_endpoint' =>  array(
        'title' => __('Endpoint', 'woocommerce'),
        'type' => 'text',
        'description' => __('Input your Duitku Endpoint (e.g https://api-sandbox.duitku.com).', 'woocommerce'),
        'default' => ''
      ),
      'expiry_period' => array(
        'title' => __('Expiry Period', 'woocommerce'),
        'type' => 'text',
        'description' => '<br />' . sprintf(__('The validity period of the transaction before it expires. (e.g 1 - 1440 ( min ))<br /><br /><br /><br />Log Path: <code>%s</code>', 'woocommerce'), wc_get_log_file_path('duitku')),
        'default' => '10'
      )
    );
  }

  function process_payment($order_id)
  {
    global $woocommerce;
    // Create the order object
    $order = new WC_Order($order_id);

    $this->log('Generating payment form for order ' . $order->get_order_number() . '. Notify URL: ' . $this->redirect_url);

    $url = $this->endpoint . '/api/merchant/createInvoice';
    $lang = $this->lang;
    $currency = $this->currency;
    //$signature = md5($this->merchantCode . '' . $order_id . '' . intval($order->order_total) . $this->apiKey);
    $tstamp = round(microtime(true) * 1000);
    $mcode = $this->merchantCode;
    $header_signature = hash('sha256', $mcode . $tstamp . $this->apiKey);
    $current_user = $order->billing_first_name . " " . $order->billing_last_name;

    $item_details = [];

    foreach ($order->get_items() as $item_key => $item) {
      // $product      = $item->get_product();
      $item_name    = $item->get_name();
      $quantity     = $item->get_quantity();
      $product_price  = $item->get_subtotal();
      // $item_beli = $item;

      $item_details[] = array(
        'name' => $item_name,
        'price' => intval($product_price),
        'quantity' => $quantity
      );
    }

    // Shipping fee as item_details
    if ($order->get_total_shipping() > 0) {
      $item_details[] = array(
        'name' => 'Shipping Fee',
        'price' => ceil($order->get_total_shipping()),
        'quantity' => 1
      );
    }

    // Tax as item_details
    if ($order->get_total_tax() > 0) {
      $item_details[] = array(
        'name' => 'Tax',
        'price' => ceil($order->get_total_tax()),
        'quantity' => 1
      );
    }

    // Discount as item_details
    if ($order->get_total_discount() > 0) {
      $item_details[] = array(
        'name' => 'Total Discount',
        'price' => ceil($order->get_total_discount())  * -1,
        'quantity' => 1
      );
    }

    // Fees as item_details
    if (sizeof($order->get_fees()) > 0) {
      $fees = $order->get_fees();
      $i = 0;
      foreach ($fees as $item) {
        $item_details[] = array(
          'name' => $item['name'],
          'price' => ceil($item['line_total']),
          'quantity' => 1
        );
        $i++;
      }
    }

    // throw new Exception(__($item_beli,'duitku'));

    $customer_details = array(
      'firstName' => $order->billing_first_name,
      'lastName' => $order->billing_last_name,
      'email' => $order->billing_email,
      'phoneNumber' => $order->billing_phone,
    );

    $shipping_address = array(
      'firstName' => $order->shipping_first_name,
      'lastName' => $order->shipping_last_name,
      'address' => $order->shipping_address_1 . " " . $order->shipping_address_2,
      'city' => $order->shipping_city,
      'postalCode' => $order->shipping_postcode,
      'phone' => $order->billing_phone,
      'countryCode' => $order->shipping_country
    );

    $billing_address = array(
      'firstName' => $order->billing_first_name,
      'lastName' => $order->billing_last_name,
      'address' => $order->billing_address_1 . " " . $order->billing_address_2,
      'city' => $order->billing_city,
      'postalCode' => $order->billing_postcode,
      'phone' => $order->billing_phone,
      'countryCode' => $order->billing_country
    );

    $customer_details['billingAddress'] = $billing_address;
    $customer_details['shippingAddress'] = $shipping_address;

    $params = array(
      'merchantOrderId' => '' . $order_id . '',
      'merchantUserInfo' => $current_user,
      'paymentAmount' => intval($order->order_total),
      'paymentMethod' => $this->payment_method,
      'expiryPeriod' => intval($this->expiryPeriod),
      'productDetails' => get_bloginfo() . ' Order : #' . $order_id,
      'additionalParam' => '',
      'email' => $order->billing_email,
      'phoneNumber' => $order->billing_phone,
      'returnUrl' => esc_url_raw($this->redirect_url),
      'callbackUrl' => esc_url_raw($this->redirect_url) . '?status=notify',
      'customerDetail' => $customer_details,
      'itemDetails' => $item_details
    );

    if (self::$validation) {
      WC_Gateway_Duitku_Validation::duitkuRequest($params);
    }
    
    if (self::$sanitized) {
      WC_Gateway_Duitku_Sanitized::duitkuRequest($params);
    }

    $this->log("Create a request for inquiry");
    $this->log(json_encode($params, true));
    
    $headers = array(
      'Content-Type' => 'application/json',
      'x-duitku-signature' => $header_signature,
      'x-duitku-timestamp' => $tstamp,
      'x-duitku-merchantCode' => $mcode
    );

    $args = array(
      'body'        => json_encode($params),
      'timeout'     => '90',
      'httpversion' => '1.0',
      'headers'     => $headers,
  );
  

    // Receive server response ...
    $response = wp_remote_post($url, $args);

    $this->log('raw response: ' . json_encode($response));
    $httpcode = wp_remote_retrieve_response_code($response);//curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $server_output = wp_remote_retrieve_body($response);//curl_exec($ch);

    $successResponse = array(
      'result'  => 'success',
      'redirect' => ''
    );

    $order->save();

    if (!empty($server_output)) {
      $resp = json_decode($server_output);
      if (isset($resp->statusCode)) {
        if ($resp->statusCode == "00") {

          $this->log('Inquiry Success for order Id ' . $order->get_order_number() . ' with reference number ' . $resp->reference);

          $order->update_meta_data('_duitku_pg_reference', $resp->reference);

          if ($this->uiMode == "popup") {
            $redirectUrl = $order->get_checkout_payment_url(true) . "&referenceNumber=" . $resp->reference;
          } else if ($currency !== "idr") {
            $redirectUrl = $resp->paymentUrl . "&lang=" . $lang . "&currency=" . $currency;
          } else {
            $redirectUrl = $resp->paymentUrl . "&lang=" . $lang;
          }

          $successResponse["redirect"] = $redirectUrl;
          return $successResponse;
        } else {
          wc_add_notice($server_output, "notice", array());
        }
        WC()->cart->empty_cart();
      } else {
        if ($server_output == "Minimum Payment 10000") {
          wc_add_notice("Minimum Payment Rp.10000", "notice", array());
        } else {
          wc_add_notice($server_output, "notice", array());
        }
      }
      // throw new Exception(__($resp,'duitku'));
    } else {
      $this->log('Inquiry failed for order Id ' . $order->get_order_number());
      // Transaction was not succesful Add notice to the cart

      if ($httpcode == "400") {
        wc_add_notice($resp->Message, 'error');
        // Add note to the order for your reference
        $order->add_order_note('Error:' .  $resp->Message);
      } else {
        wc_add_notice("error processing payment", 'error');
        // Add note to the order for your reference
        $order->add_order_note('Error: error processing payment.');
      }
      return;
    }

    //log response from server
    $this->log('response: ' . $server_output);
    $this->log('response code: ' . $httpcode);
    $this->log($url);
  }

  function receipt_page($order_id)
  {
    global $woocommerce;
    $pluginName = 'fullpayment';
    // Separated as Shared PHP included by multiple class
    require_once(dirname(__FILE__) . '/payment-page.php');
  }

  protected function validate_transaction($order_id)
  {
    $url = $this->endpoint . '/api/merchant/transactionStatus';
    $signature = md5($this->merchantCode . $order_id . $this->apiKey);
    $params = array(
      'merchantCode' => $this->merchantCode, // API Key Merchant /
      'merchantOrderId' => $order_id,
      'signature' => $signature
    );

    $headers = array(
      'Content-Type' => 'application/json',
    );

    $this->log("validate transaction:");
    $this->log(var_export(json_encode($params), true));
    $this->log("validate url: " . $url);

    // Receive server response ...
    $response = wp_remote_post($url, array(
      'body' => json_encode($params),
      'httpversion' => '1.0',
      'timeout' => '90',
      'sslverify' => false,
      'headers'     => $headers,
    ));
    $httpcode = wp_remote_retrieve_response_code($response);//curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $server_output = wp_remote_retrieve_body($response);//curl_exec($ch);

    $this->log("response: " . $server_output);
    $this->log("response Code: " . $httpcode);

    return $server_output;
  }

  function duitku_checkout_response()
  {

    $params = [];
    $params['resultCode'] = isset($_REQUEST['resultCode']) ? sanitize_text_field($_REQUEST['resultCode']) : null;
    $params['status'] = isset($_REQUEST['status']) ? sanitize_text_field($_REQUEST['status']) : null;
    $params['merchantOrderId'] = isset($_REQUEST['merchantOrderId']) ? sanitize_text_field($_REQUEST['merchantOrderId']) : null;
    $params['reference'] = isset($_REQUEST['reference']) ? sanitize_text_field($_REQUEST['reference']) : null;

    //$params_string = json_encode($params);
    //file_put_contents('log_duitkupop_callback.txt', "* " . $params_string  . " *\r\n\r\n", FILE_APPEND | LOCK_EX);
    $this->log("param response: ");
    $this->log(json_encode($params, true));

    if (!empty($params['status']) && $params['status'] == 'notify') {
      $order_id = wc_clean(stripslashes($params['merchantOrderId']));
      $result_code = wc_clean(stripslashes($params['resultCode']));
      $reference_number = wc_clean(stripslashes($params['reference']));
    } else {
      $order_id = isset($_GET['merchantOrderId']) ? sanitize_text_field($_GET['merchantOrderId']) : null;
      $result_code = isset($_GET['resultCode']) ? sanitize_text_field($_GET['resultCode']) : null;
      $reference_number = isset($_GET['reference']) ? sanitize_text_field($_GET['reference']) : null;
    }

    if (empty($result_code) || empty($order_id) || empty($reference_number)) {
      throw new Exception(__(
        'wrong query string please contact admin.',
        'duitku'
      ));
      // return;
    } else {
      // error_log($this->get_return_url( $order )); //debug
      $order = new WC_Order($order_id);

      // wp_redirect( get_permalink( woocommerce_get_page_id( 'shop' ) ) );
      // exit;
      $this->log("result code: " . $result_code);

      if ($result_code == "00") {
        $respon = json_decode($this->validate_transaction($order_id));
        update_post_meta($order_id, '_duitku_result_code', $respon->statusCode);
        update_post_meta($order_id, '_duitku_reference_number', $reference_number);
        if ($respon->statusCode == "00") {
          $order->payment_complete();
          $order->add_order_note(__('Pembayaran telah dilakukan melalui duitku dengan id ' . $order_id . ' Dan No Reference ' . $reference_number, 'woocommerce'));
          wc_add_notice('Pembayaran dengan duitku telah berhasil.');
          $this->log("Pembayaran dengan order ID " . $order_id . " telah berhasil.");
        } else {
          wc_add_notice('Pembayaran dengan duitku tertunda.');
          $this->log("Pembayaran dengan order ID " . $order_id . " tertunda.");
        }
        return wp_redirect($order->get_checkout_order_received_url());
      } else if ($result_code == "01") {
        update_post_meta($order_id, '_duitku_result_code', $result_code);
        update_post_meta($order_id, '_duitku_reference_number', $reference_number);
        wc_add_notice('Pembayaran dengan duitku tertunda.');
        $this->log("Pembayaran dengan order ID " . $order_id . " tertunda.");
        return wp_redirect($order->get_view_order_url());
      } else if ($result_code == "02") {
        $respon = json_decode($this->validate_transaction($order_id));
        update_post_meta($order_id, '_duitku_result_code', $respon->statusCode);
        update_post_meta($order_id, '_duitku_reference_number', $reference_number);
        if ($respon->statusCode == "02") {
          WC()->cart->empty_cart();
          $order->update_status('failed');
          $order->add_order_note('Pembayaran dengan duitku gagal');
          wc_add_notice('Pembayaran dengan duitku gagal.', 'error');
          $this->log("Pembayaran dengan order ID " . $order_id . " gagal.");
          $this->log("respon status code");
          return wp_redirect($order->get_cancel_order_url());
          throw new Exception(_('Pembayaran Gagal.', 'duitku'));
        } else if ($respon->statusCode == "01") {
          WC()->cart->empty_cart();
          wc_add_notice('Pembayaran dengan duitku tertunda.');
          $this->log("Pembayaran dengan order ID " . $order_id . " tertunda.");
          return wp_redirect($order->get_view_order_url());
        }
      } else {
        // wp_redirect($order->get_checkout_payment_url(true) . "&referenceNumber=" . $reference_number);
        WC()->cart->empty_cart();
        $order->update_status('failed');
        $order->add_order_note('Pembayaran dengan duitku gagal');
        wc_add_notice('Pembayaran dengan duitku gagal.', 'error');
        $this->log("Pembayaran dengan order ID " . $order_id . " gagal.");
        $this->log("result code");
        return wp_redirect($order->get_cancel_order_url());
        throw new Exception(_('Pembayaran Gagal.', 'duitku'));
      }

      // throw new Exception(__($respon->statusCode, 'duitku'));

    }
  }

  public function duitku_finish_page($order_id)
  {
    require_once(dirname(__FILE__) . '/duitku-finish-page.php');
  }

  /**
   * function to generate log for debugging
   * to activate loggin please set debug to true in admin configuration
   * @param type $message
   * @return type
   */
  public static function log($message)
  {
    if (self::$log_enabled) {
      if (empty(self::$log)) {
        self::$log = new WC_Logger();
      }
      self::$log->add('duitku-pop', $message);
    }
  }
}
