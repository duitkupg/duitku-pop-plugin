<?php
$wp_base_url = home_url( '/' );

$finish_url = $wp_base_url."?wc-api=WC_Gateway_Duitku_Pop";
$finish_url = '"'.$finish_url.'&merchantOrderId="+result.merchantOrderId+"&resultCode="+result.resultCode+"&reference="+result.reference';
$plugin_status = $this->pluginStatus;
$endpoint = $this->endpoint;

if ($plugin_status == 'sandbox') {
  $library_script_url = "https://app-sandbox.duitku.com/lib/js/duitku.js";
}elseif ($plugin_status == 'production') {
  $library_script_url = "https://app-prod.duitku.com/lib/js/duitku.js";
}

$reference = $_GET['referenceNumber'];
?>

<script id="library_duitku" src="<?php echo $library_script_url;?>"></script>

<a id="checkout-button" title="Checkout" class="button alt">Loading Duitku Payment...</a>

<script type="text/javascript">
var checkoutButton = document.getElementById("checkout-button");

document.addEventListener("DOMContentLoaded", function(event) {
  var referenceNumber = "<?php echo esc_js($reference)?>";

  function loadLibrary(src) {
    if (document.getElementById('library_duitku'))
    return;
    var c = document.createElement("script");
    c.src = src;
    document.body.appendChild(c);
  }

  var retryCount = 0;
  var checkoutRunning = false;
  var intervalFunction = 0;

  function runCheckoutDuitku() {
    intervalFunction = setInterval(function() {
      try{
        checkout.process(referenceNumber, {
          successEvent: function(result){
            checkoutButton.innerHTML = "Payment Process Success";
            window.location = <?php echo $finish_url;?>;
            console.log('success');
            console.log(result);
          },
          pendingEvent: function(result){
            checkoutButton.innerHTML = "Payment Process Pending";
            window.location = <?php echo $finish_url;?>;
            console.log('pending');
            console.log(result);
          },
          errorEvent: function(result){
            checkoutButton.innerHTML = "Payment Process Error";
            console.log('error');
            console.log(result);
          },
          closeEvent: function(result){
            checkoutButton.innerHTML = "Payment Process Not Finished (Click to retry payment process)";
            console.log('customer closed the popup without finishing the payment');
            console.log(result);
          }
        });
        checkoutRunning = true;
      } catch (e){
        retryCount++;
        if(retryCount >= 10){
          location.reload(); checkoutButton.innerHTML = "Loading Duitku Payment..."; return;
        }
        console.log(e);
        console.log("Duitku Checkout belum termuat sempurna... mencoba dalam 1000ms!");
      } finally {
        if (checkoutRunning) {
          clearInterval(intervalFunction);
        }
      }
    }, 1000);
  }

  loadLibrary("<?php echo esc_js($library_script_url);?>");

  var clickCount = 0

  checkoutButton.onclick = function(){
    if(clickCount >= 2){
      location.reload();
      checkoutButton.innerHTML = "Loading Duitku Payment...";
      return;
    }
    runCheckoutDuitku();
    checkoutButton.innerHTML = "Proceed To Payment";
    clickCount++;
  };

  runCheckoutDuitku();
  checkoutButton.innerHTML = "Proceed To Payment";

});

</script>
