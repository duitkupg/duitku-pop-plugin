<?php
// Heading
$_['heading_title']      = 'Duitku Payment';

// Text
$_['text_payment']       = 'Payment';
$_['text_success']       = 'Success: You have modified Duitku account details!';
$_['text_duitku_pop'] = '<img src="view/image/payment/duitku_thumb.png" width="auto" height = "25" alt="Duitku Payment" title="Duitku" />';
$_['text_live']          = 'Production';
$_['text_successful']    = 'Always Successful';
$_['text_fail']          = 'Always Fail';
$_['text_edit']          = 'Configure Duitku Payment Gateway';

$_['entry_plugin_status']  = 'Plugin Status';
$_['entry_endpoint']     = 'URL Endpoint';
$_['entry_merchant']     = 'Merchant Code';
$_['entry_api_key']      = 'Merchant API Key';
$_['entry_test']         = 'Test Mode:';
$_['entry_total']        = 'Total:<br /><span class="help">The checkout total the order must reach before this payment method becomes active.</span>';
$_['entry_order_status'] = 'Order Status:';
$_['entry_geo_zone']     = 'Geo Zone:';
$_['entry_status']       = 'Status:';
$_['entry_sort_order']   = 'Sort Order:';
$_['entry_duitku_pop_success_mapping'] = 'Map Payment Success Status to Order Status:';
$_['entry_duitku_pop_pending_mapping'] = 'Map Payment Pending Status to Order Status:';
$_['entry_duitku_pop_failure_mapping'] = 'Map Payment Failure Status to Order Status:';
$_['entry_display_name'] = 'Display name:';
$_['entry_expiry_period'] = 'Expiry Period';
$_['entry_ui_mode'] = 'UI Mode';
$_['development_status'] = 'Development';
$_['sandbox_status'] = 'Sandbox';
$_['production_status'] = 'Production';
$_['popup_mode'] = 'Popup';
$_['redirect_mode'] = 'Redirect';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the Duitku Payment!';
$_['error_merchant_code'] = 'Merchant Code is required!';
$_['error_api_key'] = 'API Key is required!';
$_['error_currency_conversion'] = 'Currency conversion rate is required when IDR currency is not installed in the system!';
$_['error_display_name'] = 'Please specify a name for this payment method!';
$_['error_endpoint'] = 'URL Endpoint is required!';
?>
