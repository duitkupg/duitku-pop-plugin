<?php
// Text
// Heading
$_['heading_title']     = 'Thank you for shopping with us ';
$_['warning_title']     = 'Duitku Payment Warning';

// Text
$_['text_title']        = 'Duitku Payment';
$_['text_response']     = 'Response from Payment:';
$_['text_success']      = '... your payment was successfully received.';
$_['text_success_wait'] = '<b><span style="color: #FF0000">Please wait...</span></b> whilst we finish processing your order.<br>If you are not automatically re-directed in 10 seconds, please click <a href="%s">here</a>.';
$_['text_failure']      = 'Thank you for your order. We are waiting for payment. <br> Order will be processed after payment is received.';
$_['text_failure_wait'] = '<b><span style="color: #FF0000">Please wait...</span></b><br>If you are not automatically re-directed in 10 seconds, please click <a href="%s">here</a>.';
?>
